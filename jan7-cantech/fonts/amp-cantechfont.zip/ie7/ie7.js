/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'amp-cantechfont\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-email-envelope': '&#xf003;',
		'icon-facebook-like': '&#xf087;',
		'icon-twitter-bird': '&#xf099;',
		'icon-facebook-f': '&#xf09a;',
		'icon-pinterest': '&#xf0d2;',
		'icon-google-plus': '&#xf0d5;',
		'icon-linkedin': '&#xf0e1;',
		'icon-tumblr': '&#xf173;',
		'icon-stumbleupon': '&#xf1a4;',
		'icon-digg': '&#xf1a6;',
		'icon-wechat': '&#xf1d7;',
		'icon-whatsapp': '&#xf232;',
		'icon-odnoklassniki': '&#xf263;',
		'icon-pocket-social': '&#xf265;',
		'icon-reddit-alien': '&#xf281;',
		'icon-telegram-social': '&#xf2c9;',
		'icon-favicon': '&#xe917;',
		'icon-cantech-logo': '&#xe918;',
		'icon-cantech-letter-logo': '&#xe922;',
		'icon-life-sciences': '&#xe919;',
		'icon-fintech': '&#xe91a;',
		'icon-newsletter': '&#xe900;',
		'icon-quote-bubble': '&#xe901;',
		'icon-search': '&#xe902;',
		'icon-cannabis': '&#xe903;',
		'icon-software': '&#xe904;',
		'icon-cleantech': '&#xe905;',
		'icon-blockchain': '&#xe906;',
		'icon-analyst': '&#xe907;',
		'icon-ppt-file': '&#xe908;',
		'icon-docx-file': '&#xe909;',
		'icon-xls-file': '&#xe90a;',
		'icon-eps-file': '&#xe90b;',
		'icon-zip-file': '&#xe90c;',
		'icon-doc-file': '&#xe90d;',
		'icon-pdf-file': '&#xe90e;',
		'icon-txt-file': '&#xe90f;',
		'icon-rss': '&#xe910;',
		'icon-chevron-down': '&#xe911;',
		'icon-chevron-up': '&#xe930;',
		'icon-home': '&#xe912;',
		'icon-info': '&#xe913;',
		'icon-menu': '&#xe914;',
		'icon-play': '&#xe916;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
